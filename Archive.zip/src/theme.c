#include "nav_theme.h"
const NavTheme *nav_theme_classic_dos(void){static const NavTheme theme={"classic-dos",{7,14,3,0,14},{1,1,0,3,1}};return &theme;}
