#include "nav.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
int nav_platform_launch_tdx(const char *path,char *err,size_t n){int status;pid_t pid=fork();if(pid<0){snprintf(err,n,"cannot launch TDX: %s",strerror(errno));return -1;}if(pid==0){execlp("tdx","tdx",path,(char *)NULL);_exit(127);}if(waitpid(pid,&status,0)<0){snprintf(err,n,"cannot wait for TDX: %s",strerror(errno));return -1;}if(!WIFEXITED(status)||WEXITSTATUS(status)!=0){snprintf(err,n,"TDX exited unsuccessfully");return -1;}return 0;}
